<?php
    defined( 'ABSPATH' ) || die();
